import json

import httpx
import requests
from bs4 import BeautifulSoup


class Book:
    def __init__(self, book_id, cookie):
        from . import ua
        self.headers = {
            "User-Agent": ua,
            "Cookie": cookie
        }
        self.client = httpx.Client(headers=self.headers)

        self.image = None
        self.chapter_num = None
        self.soup = None
        self.intro = None
        self.author_name = None
        self.img_url = None
        self.title = None
        self.html_text = None
        self.book_id = book_id

        self.volumes_object = []
        self.index = 0

    def get_book_info(self):
        url = f'https://fanqienovel.com/page/{self.book_id}'
        with httpx.Client(headers=self.headers) as client:
            response = client.get(url)
            self.html_text = response.text
            
    def get_image(self):
        response = requests.get(self.img_url)
        self.image = response.content

    def parse_web_page(self):
        self.soup = BeautifulSoup(self.html_text, 'html.parser')

        self.title = self.soup.find("h1").get_text()
        self.intro = self.soup.find("div", class_="page-abstract-content").get_text()
        self.author_name = self.soup.find('span', class_='author-name-text').get_text()

        self.chapter_num = len(self.soup.find_all("div", class_="chapter-item"))

    def parse_images(self):
        script_tag = self.soup.find('script', type='application/ld+json')
        json_data = json.loads(script_tag.string)
        images_data = json_data.get('image', [])
        self.img_url = images_data[0]

    def parse_volume(self):
        from . import Volume

        page_directory_content = self.soup.find('div', class_='page-directory-content')
        nested_divs = page_directory_content.find_all('div', recursive=False)
        volume_id = 0
        for nested_div in nested_divs:
            volume_id += 1
            volume_name = nested_div.find('div', class_='volume').text
            chapters = nested_div.find_all("div", class_="chapter-item")

            self.volumes_object.append(Volume(volume_id, volume_name, chapters, self.client))

    def __iter__(self):
        self.index = 0
        return self

    def __next__(self):
        if self.index >= len(self.volumes_object):
            raise StopIteration
        volume = self.volumes_object[self.index]
        self.index += 1
        return volume
