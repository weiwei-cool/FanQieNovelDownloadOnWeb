import re


class Volume:
    def __init__(self, volume_id: int, volume_name: str, chapters: list, client: object):
        self.volume_id = volume_id
        self.volume_title = volume_name
        self.chapters = chapters

        self.client = client

        self.chapters_object = []
        self.index = 0

    def parse_chapter(self):
        from . import Chapter

        chapter_id_index = 0
        for chapter in self.chapters:
            chapter_id_index += 1
            chapter_title = chapter.find("a").get_text()
            chapter_id = re.search(r"/reader/(\d+)", chapter.find("a")["href"]).group(1)

            self.chapters_object.append(Chapter(chapter_id_index, chapter_title, chapter_id, self.client))

    def __iter__(self):
        self.index = 0
        return self

    def __next__(self):
        if self.index >= len(self.chapters_object):
            raise StopIteration
        chapter = self.chapters_object[self.index]
        self.index += 1
        return chapter
