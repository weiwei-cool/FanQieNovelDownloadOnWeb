from bs4 import BeautifulSoup


class Chapter:
    def __init__(self, chapter_id_index: int, chapter_title: str, chapter_id: int, client: object):
        self.page_html = None

        self.chapter_id = chapter_id
        self.chapter_title = chapter_title
        self.chapter_id_index = chapter_id_index

        self.client = client

        self.str_content = None
        self.html_content = None

        self.img_tags = None
        self.img_urls = None

    def get_html_content(self):
        response = self.client.get(f'https://fanqienovel.com/reader/{self.chapter_id}')
        self.page_html = response.text

    def parse_content(self):
        soup = BeautifulSoup(self.page_html, 'html.parser')
        html_chapter = soup.find('div', class_='muye-reader-content noselect').find('div')
        self.html_content = str(html_chapter)

        self.str_content = '\n\n'.join(p.text for p in html_chapter.find_all('p'))

    def decrypt_content(self):
        from . import map_text

        self.html_content = ''.join(map_text.get(ord(char), char) for char in self.html_content)
        self.str_content = ''.join(map_text.get(ord(char), char) for char in self.str_content)

    def parse_img_content(self):
        soup = BeautifulSoup(self.html_content, 'html.parser')
        self.img_tags = soup.find_all('img')
        self.img_urls = []

        if self.img_tags:
            for index, img in enumerate(self.img_tags):
                self.img_urls.append(img['src'])
                img['src'] = f'Illustrations/{self.chapter_id_index}_{index}.jpg'

            self.html_content = str(soup)

    def get_img_content(self, url):
        response = self.client.get(url)
        return response.content
